import 'package:attendance_portal/Students.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Attendance Portal',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Portal(),
    );
  }
}

class Portal extends StatefulWidget {
  Portal({Key? key}) : super(key: key);

  @override
  State<Portal> createState() => _PortalState();
}

class _PortalState extends State<Portal> {

  void showToast(){
    Fluttertoast.showToast(
        msg: 'Attendance is Saved',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.grey,
        textColor: Colors.black
    );
  }

  List<Student> students = [
    new Student(roll: "BSCS20001", name: "Samee Haider"),
    new Student(roll: "BSCS20002", name: "Umer Khalid"),
    new Student(roll: "BSCS20004", name: "Rafay Naeem"),
    new Student(roll: "BSCS200014", name: "Danish"),
    new Student(roll: "BSCS200056", name: "Sabooh Taha"),
  ];

  Widget buildText(String text){
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Text(
                text,
                style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold
            ),
          ),
    );
  }

  Widget buildCheckBox(int index){
    return Checkbox(
      value: this.students[index].isPresent,
      onChanged: (bool? value){
        setState(() {
          this.students[index].isPresent = value!;
        });
      },
    );
  }

  Widget buildNameText(int index){
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Text(
        students[index].name,
      ),
    );
  }

  Widget buildRollText(int index){
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Text(
        students[index].roll,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Attendance Portal"),
      ),

      body: Column(
        children: [
          Container(
            alignment: Alignment.center,
            width: MediaQuery.of(context).size.width * 1.0,
            child: Column(
              children: [
                Container(
                  child: Table(
                    children: [
                      TableRow(
                        children: [
                          buildText("Attendace"),
                          buildText("Roll"),
                          buildText("Name"),
                        ]
                      ),

                      TableRow(
                        children: [
                          buildCheckBox(0),
                          buildRollText(0),
                          buildNameText(0),
                        ]
                      ),

                      TableRow(
                          children: [
                            buildCheckBox(1),
                            buildRollText(1),
                            buildNameText(1),
                          ]
                      ),

                      TableRow(
                          children: [
                            buildCheckBox(2),
                            buildRollText(2),
                            buildNameText(2),
                          ]
                      ),

                      TableRow(
                          children: [
                            buildCheckBox(3),
                            buildRollText(3),
                            buildNameText(3),
                          ]
                      ),

                      TableRow(
                          children: [
                            buildCheckBox(4),
                            buildRollText(4),
                            buildNameText(4),
                          ]
                      ),
                    ],
                  ),
                ),

                ElevatedButton(
                  onPressed: (){
                    showToast();
                  },
                  child: Container(
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(12)
                    ),
                    alignment: Alignment.center,
                    child: const Text(
                        "Submit",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

