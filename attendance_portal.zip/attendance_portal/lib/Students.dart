
class Student{
  String roll = "";
  String name = "";
  bool isPresent = false;

  Student({required String name, required String roll}){
    this.roll = roll;
    this.name = name;
    this.isPresent = false;
  }
}