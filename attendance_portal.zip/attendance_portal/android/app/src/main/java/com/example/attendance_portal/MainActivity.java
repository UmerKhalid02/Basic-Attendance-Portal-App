package com.example.attendance_portal;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
